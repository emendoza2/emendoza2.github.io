-- Version --
-- 0.0.1 --
saveProjectInfo("Version","0.0.1")

-- Developer --
-- Elijah Mendoza --
saveProjectInfo("Developer","Elijah Mendoza")

-- Error codes --
--[[
1 : Invalid world (nil)
2 : Invalid world (no rows)
--]]

-- Version history --